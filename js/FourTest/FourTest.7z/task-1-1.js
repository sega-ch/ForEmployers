const user = {
    name: "Sir",
    surname: "Francis",
    patranomic: "Drake",

    print: function() {
        alert(`${this.name} ${this.surname} ${this.patranomic}`);
    }
};

user.print();