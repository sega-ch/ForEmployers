const elem1 = document.getElementById("elem1");
const elem2 = document.getElementById("elem2");
const elem3 = document.getElementById("elem3");

console.log(elem1);

//В задании просят использовать document.querySeletor, но в html элементах используют id, а не класс?!
