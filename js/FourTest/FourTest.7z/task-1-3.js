const elem1 = document.querySelector("p");
let newItem = "";
newItem = elem1.textContent;

console.log(newItem);