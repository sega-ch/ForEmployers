const btn1 = document.querySelector(".btn-1");
const btn2 = document.querySelector(".btn-2");
const btn3 = document.querySelector(".btn-3");
const div = document.querySelector("div");

btn1.addEventListener('click', function(ev) {

    console.log("1");

} )

btn2.addEventListener('click', function(ev) {

    console.log("2");

} )

btn3.addEventListener('click', function(ev) {

    console.log("3");

} )