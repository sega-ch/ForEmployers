let userPoints = 0;
let programmPoints = 0;
const words = ["москва", "питер", "агросити", "рига", "амстердам", "ижевск", "кастрома"]
const usedWords = [];
let isActive = false;

while (true)
{
    let userAnswer = prompt("Пиши");
   
    for ( let obj in usedWords)
    {

        if (obj !== userAnswer)
        {
            for (let i = 0; i < cities.length; i++)
            {
            
                if ( userAnswer.toString().slice(-1) === cities[i][0]) {
            
                    alert(cities[i]);
                    usedWords.push(userAnswer);
                    usedWords.push( cities[i]);
                    cities.splice( i, 1);
                    break;
        
                } else if (userAnswer.toString().slice(-1) === "ы" || userAnswer.toString().slice(-1) === "ъ" || userAnswer.toString().slice(-1) === "й" || userAnswer.toString().slice(-1) === "ь") {
        
                    if ( userAnswer.toString().slice(-2) === cities[i][0]) {
            
                        alert(cities[i]);
                        usedWords.push(userAnswer);
                        usedWords.push( cities[i]);
                        cities.splice( i, 1);
                        break;
            
                    } else if (userAnswer.toString().slice(-2) && i === cities.length-1 ) { alert( `Слова на букву ${userAnswer.toString().slice(-1)} закончились` );  }
        
                }
                    
                
            }   
            break;       
        } else {alert("Это слово уже было");}

    }

    
} 
 


