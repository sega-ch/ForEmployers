const numbers = [100, -5, 200, 0, 50, -150, 20];

for (let i of numbers)
{
    if (numbers[i] > 0)
    {
        console.log(numbers[i]);
    }
}