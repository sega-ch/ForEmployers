const numbers = [100, -5, 200, 0, 50, -150, 20];

numbers.forEach((element) => {
    
    console.log(element+50);

});

console.log(numbers);
