import React from "react";

function Greeting() {
    return (
        <h1> Hello Wrold!</h1>
    );
}

export default Greeting;